function love.conf(t)
author = "rude, and Codingale for the conversion to 0.9.0"
love_version = "0.9.0"
end
