Love-Examples
----------------------

[L&Ouml;VE][LOVE] examples 

[LOVE]: http://love2d.org